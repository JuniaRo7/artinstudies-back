package bra.edu.ifsp.artinstudies.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import bra.edu.ifsp.artinstudies.model.Livro;
import bra.edu.ifsp.artinstudies.repository.LivroRepository;

@RestController
public class LivroController {
    
    // método GET
    @GetMapping("/livro")
    public List<Livro> listaLivros(){
        return LivroRepository.all();
    }
    
    //método GET por ID
    @GetMapping("/livro/{id}")
    public Livro RecuperaLivroPeloId(@PathVariable("id") int id) {
        return LivroRepository.getById(id);
    }
    
    // método DELETE

    @DeleteMapping("/livro/deletar_livro/{id}")
    public Livro DeletarLivroPeloId(@PathVariable("id") int id){
        return LivroRepository.deletById(id);
    }

    // método POST

    @PostMapping("/livro")
    public void addLivro(
            @RequestBody Livro Livro) {
        LivroRepository.add(Livro);
    }
}
