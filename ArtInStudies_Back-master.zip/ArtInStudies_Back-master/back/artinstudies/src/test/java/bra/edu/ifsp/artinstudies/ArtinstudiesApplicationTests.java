package bra.edu.ifsp.artinstudies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtinstudiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
